IrrNewt version 0.4 released on 10 June 2007
Copyright (c) 2007 Mancuso "white_tiger" Raffaele

IrrNewt is released under the terms of LGPL. You can find a copy of the license in license.txt file
